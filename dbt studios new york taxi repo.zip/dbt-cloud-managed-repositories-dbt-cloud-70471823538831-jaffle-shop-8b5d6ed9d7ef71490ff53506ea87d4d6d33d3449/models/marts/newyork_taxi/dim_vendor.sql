SELECT DISTINCT
    vendor_id,

    CASE vendor_id
        WHEN 1 THEN 'Creative Mobile Technologies'
        WHEN 2 THEN 'VeriFone'
        ELSE 'Unknown'
    END AS vendor_name

FROM {{ ref('stg_yellow_trips') }}