select LOCATIONID as location_id,
       BOROUGH, 
       ZONE, 
       SERVICE_ZONE
from {{ source('newyork_yellowtaxi', 'taxi_zone_lookup') }}