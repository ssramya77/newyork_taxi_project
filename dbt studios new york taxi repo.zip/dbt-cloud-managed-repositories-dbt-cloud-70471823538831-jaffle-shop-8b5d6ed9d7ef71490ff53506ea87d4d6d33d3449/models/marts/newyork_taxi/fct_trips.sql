SELECT
    md5(
        coalesce(vendor_id::string,'') ||
        coalesce(pickup_ts::string,'') ||
        coalesce(dropoff_ts::string,'') ||
        coalesce(pu_location_id::string,'') ||
        coalesce(do_location_id::string,'') 
    ) as trip_id,
    vendor_id,
    payment_type,

    pu_location_id,
    do_location_id,

    passenger_count,

    trip_distance,

    fare_amount,
    tip_amount,
    total_amount,

    pickup_ts,
    dropoff_ts,

    DATEDIFF('minute', pickup_ts, dropoff_ts) AS trip_duration_minutes

FROM {{ ref('stg_yellow_trips') }}