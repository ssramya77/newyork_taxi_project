
{{ config(materialized='view') }}

with src as (
    select src
    from {{ source('newyork_yellowtaxi', 'raw_yellow_taxi') }}
)
SELECT

  /* IDs */
  TRY_TO_NUMBER(src:"VendorID"::STRING)        AS vendor_id,
  TRY_TO_NUMBER(src:"RatecodeID"::STRING)      AS ratecode_id,
  TRY_TO_NUMBER(src:"PULocationID"::STRING)    AS pu_location_id,
  TRY_TO_NUMBER(src:"DOLocationID"::STRING)    AS do_location_id,
  TRY_TO_NUMBER(src:"payment_type"::STRING)    AS payment_type,
  TRY_TO_NUMBER(src:"passenger_count"::STRING) AS passenger_count,

  src:"store_and_fwd_flag"::STRING             AS store_and_fwd_flag,

  /* money */
  TRY_TO_DOUBLE(src:"fare_amount"::STRING)             AS fare_amount,
  TRY_TO_DOUBLE(src:"extra"::STRING)                   AS extra,
  TRY_TO_DOUBLE(src:"mta_tax"::STRING)                 AS mta_tax,
  TRY_TO_DOUBLE(src:"improvement_surcharge"::STRING)   AS improvement_surcharge,
  TRY_TO_DOUBLE(src:"tip_amount"::STRING)              AS tip_amount,
  TRY_TO_DOUBLE(src:"tolls_amount"::STRING)            AS tolls_amount,
  TRY_TO_DOUBLE(src:"congestion_surcharge"::STRING)    AS congestion_surcharge,
  TRY_TO_DOUBLE(src:"Airport_fee"::STRING)             AS airport_fee,
  TRY_TO_DOUBLE(src:"total_amount"::STRING)            AS total_amount,

  TRY_TO_DOUBLE(src:"trip_distance"::STRING)           AS trip_distance,

  /* timestamps */
  DATEADD(
      'microsecond',
      TRY_TO_NUMBER(src:"tpep_pickup_datetime"::STRING),
      TO_TIMESTAMP_NTZ('1970-01-01')
  ) AS pickup_ts,

  DATEADD(
      'microsecond',
      TRY_TO_NUMBER(src:"tpep_dropoff_datetime"::STRING),
      TO_TIMESTAMP_NTZ('1970-01-01')
  ) AS dropoff_ts

from src