SELECT DISTINCT

    DATE(pickup_ts) AS pickup_date,
    EXTRACT(HOUR FROM pickup_ts) AS pickup_hour,
    EXTRACT(DAYOFWEEK FROM pickup_ts) AS day_of_week,
    EXTRACT(MONTH FROM pickup_ts) AS month,
    EXTRACT(YEAR FROM pickup_ts) AS year

FROM {{ ref('stg_yellow_trips') }}