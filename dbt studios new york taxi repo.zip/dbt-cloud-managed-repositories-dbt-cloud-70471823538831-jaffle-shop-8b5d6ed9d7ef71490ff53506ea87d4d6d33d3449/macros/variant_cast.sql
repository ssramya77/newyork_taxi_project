{% macro variant_int(v) -%}
  try_to_number({{ v }})::int
{%- endmacro %}

{% macro variant_num(v) -%}
  try_to_double({{ v }})
{%- endmacro %}